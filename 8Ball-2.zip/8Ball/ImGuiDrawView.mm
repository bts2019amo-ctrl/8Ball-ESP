#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import <mach-o/dyld.h>
#import <objc/runtime.h>
#import <dlfcn.h>

// ── LoadView infrastructure ──
#import "LoadView/ImGuiDrawView.h"
#import "LoadView/ImGuiLoad.h"
#import "LoadView/HeeeNoScreenShotView.h"

// ── ImGui ──
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_metal.h"

// ── Fonts ──
#include "ImGui/zzz.h"
#include "ImGui/Icon.h"
#include "ImGui/Iconcpp.h"
#include "ImGui/ico_font.h"

// Menu visibility is declared before ESP.h because the custom header has a close control.
static bool g_menuVisible = false;

// ── ESP system ──
#include "ESP.h"

// ── Metal device for ESP (if needed) ──
id<MTLDevice> g_espMetalDevice = nil;

// ============================================================================
// Globals
// ============================================================================

HeeeNoScreenShotView *hideViewSylphin3107 = nil;

// ── Gesture state ──
static id                       g_gestureTarget         = nil;
static __weak UIWindow         *g_gestureAttachedWindow = nil;
static UITapGestureRecognizer  *g_menuGesture           = nil;
static UITapGestureRecognizer  *g_launcherGesture       = nil;
static id                       g_launcherGestureDelegate = nil;
static int                      g_overlayInitRetryCount = 0;

// ============================================================================
// Find the game's render view (MTKView, UnityView, etc.)
// ============================================================================

static UIView *GetGameRenderView(UIView *root) {
    if (!root) return nil;
    static NSArray<NSString*> *names;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        names = @[@"MTKView", @"EAGLView", @"GLKView", @"UnityView", @"SCNView"];
    });
    for (NSString *name in names) {
        Class c = NSClassFromString(name);
        if (c && [root isKindOfClass:c]) {
            return root;
        }
    }
    for (UIView *sub in root.subviews) {
        UIView *v = GetGameRenderView(sub);
        if (v) return v;
    }
    return nil;
}

// ============================================================================
// Enable multitouch on window + game view so 3-finger gesture can fire
// ============================================================================

static void EnableMultiTouchForGameAndImGui(UIView *imguiView) {
    UIWindow *window = [UIApplication sharedApplication].keyWindow
                       ?: [UIApplication sharedApplication].windows.firstObject;
    if (window) {
        window.multipleTouchEnabled = YES;
    }
    UIView *gameRootView = window.rootViewController.view;
    if (gameRootView) {
        gameRootView.multipleTouchEnabled = YES;
        UIView *gameRenderView = GetGameRenderView(gameRootView);
        if (gameRenderView) {
            gameRenderView.multipleTouchEnabled = YES;
            gameRenderView.exclusiveTouch = NO;
        }
    }
    if (imguiView) {
        imguiView.multipleTouchEnabled = YES;
        imguiView.exclusiveTouch = NO;
    }
}

@interface ESPLauncherGestureDelegate : NSObject <UIGestureRecognizerDelegate>
@end

@implementation ESPLauncherGestureDelegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    (void)gestureRecognizer;
    if (g_menuVisible) return NO;
    UIWindow *window=touch.window ?: g_gestureAttachedWindow;
    if (!window) return NO;
    const CGFloat y=window.bounds.size.height*0.5f;
    const CGRect launcherHit=CGRectMake(0.f,fmaxf(0.f,y-42.f),68.f,84.f);
    return CGRectContainsPoint(launcherHit,[touch locationInView:window]);
}
@end

static void DrawFloatingMenuLauncher(ImVec2 displaySize) {
    if (g_menuVisible || displaySize.x<1.f || displaySize.y<1.f) return;
    const float scale=1.f;
    const ImVec2 center(27.f*scale,displaySize.y*0.5f);
    const float wave=ESP_AccentWave(0.3f);
    const float radius=19.f*scale;
    ImDrawList *draw=ImGui::GetForegroundDrawList();
    draw->AddCircleFilled(ImVec2(center.x+1.f,center.y+2.f),radius+3.f*scale,IM_COL32(0,0,0,120),36);
    draw->AddCircleFilled(center,radius,IM_COL32(10,15,29,238),36);
    draw->AddCircleFilled(center,radius-2.5f*scale,
        ImGui::ColorConvertFloat4ToU32(ESP_LiveAccent(0.95f,0.3f)),36);
    draw->AddCircle(center,radius+1.f*scale,
        ImGui::ColorConvertFloat4ToU32(ESP_LiveAccent(0.72f+0.26f*wave,0.3f)),36,1.5f*scale);
    const char *icon=ICON_FA_EYE;
    const ImVec2 text=ImGui::CalcTextSize(icon);
    draw->AddText(ImVec2(center.x-text.x*0.5f,center.y-text.y*0.5f),IM_COL32(255,255,255,250),icon);
}

// ============================================================================
// Gesture recognizer — 3-finger double-tap on UIWindow
// ============================================================================

static void gestureFired(id self, SEL _cmd, id sender) {
    dispatch_async(dispatch_get_main_queue(), ^{
        g_menuVisible = !g_menuVisible;
        NSLog(@"[ESP-AI] Menu toggled: %s", g_menuVisible ? "VISIBLE" : "HIDDEN");
    });
}

static BOOL isGestureStillAttached(void) {
    UIWindow *win = g_gestureAttachedWindow;
    if (!win || !g_menuGesture || !g_launcherGesture) return NO;
    return [win.gestureRecognizers containsObject:g_menuGesture] &&
           [win.gestureRecognizers containsObject:g_launcherGesture];
}

static void attachGestureToWindow(UIWindow *window) {
    if (!window) return;

    if (!g_gestureTarget) {
        g_gestureTarget = [[NSObject alloc] init];
        SEL sel = sel_registerName("gestureFired:");
        if (!class_getInstanceMethod([NSObject class], sel)) {
            class_addMethod([NSObject class], sel, (IMP)gestureFired, "v@:@");
        }
    }

    // Remove old gestures
    if (g_menuGesture || g_launcherGesture) {
        UIWindow *oldWin = g_gestureAttachedWindow;
        if (oldWin) {
            if (g_menuGesture) [oldWin removeGestureRecognizer:g_menuGesture];
            if (g_launcherGesture) [oldWin removeGestureRecognizer:g_launcherGesture];
        }
        g_menuGesture = nil;
        g_launcherGesture = nil;
        g_gestureAttachedWindow = nil;
    }

    if (!g_launcherGestureDelegate) g_launcherGestureDelegate = [[ESPLauncherGestureDelegate alloc] init];
    SEL sel = sel_registerName("gestureFired:");
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    tap.numberOfTapsRequired    = 2;
    tap.numberOfTouchesRequired = 3;
    tap.cancelsTouchesInView    = NO;
    tap.delaysTouchesBegan      = NO;
    tap.delaysTouchesEnded      = NO;
    [tap addTarget:g_gestureTarget action:sel];
    [window addGestureRecognizer:tap];

    UITapGestureRecognizer *launcher=[[UITapGestureRecognizer alloc] init];
    launcher.numberOfTapsRequired=1;
    launcher.numberOfTouchesRequired=1;
    launcher.cancelsTouchesInView=YES;
    launcher.delaysTouchesBegan=YES;
    launcher.delaysTouchesEnded=YES;
    launcher.delegate=(id<UIGestureRecognizerDelegate>)g_launcherGestureDelegate;
    [launcher addTarget:g_gestureTarget action:sel];
    [window addGestureRecognizer:launcher];

    g_menuGesture = tap;
    g_launcherGesture = launcher;
    g_gestureAttachedWindow = window;
    NSLog(@"[ESP-AI] Menu gestures attached (3-finger double tap + floating launcher)");
}

static void setupGestureRecognizer(void) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        UIWindow *window = [UIApplication sharedApplication].keyWindow ?: [UIApplication sharedApplication].windows.firstObject;
        if (!window) {
            static int retryCount=0;
            if (retryCount++<20) dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(0.5*NSEC_PER_SEC)),
                dispatch_get_main_queue(), ^{ setupGestureRecognizer(); });
            return;
        }

        attachGestureToWindow(window);

        static dispatch_once_t observerOnce;
        dispatch_once(&observerOnce, ^{
            [[NSNotificationCenter defaultCenter]
             addObserverForName:UIApplicationDidBecomeActiveNotification
             object:nil
             queue:[NSOperationQueue mainQueue]
             usingBlock:^(NSNotification *note) {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)),
                               dispatch_get_main_queue(), ^{
                    UIWindow *currentWindow = [UIApplication sharedApplication].keyWindow;
                    if (!currentWindow) return;
                    if (!isGestureStillAttached() || g_gestureAttachedWindow != currentWindow) {
                        attachGestureToWindow(currentWindow);
                    }
                    EnableMultiTouchForGameAndImGui(nil);
                });
            }];
        });
    });
}


static ImGuiDrawView *_sharedImGuiDrawView = nil;

static void setupGestureAndShowImGui(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!_sharedImGuiDrawView) {
            _sharedImGuiDrawView = [[ImGuiDrawView alloc] init];
        }

        UIWindow *window = [UIApplication sharedApplication].keyWindow
                           ?: [UIApplication sharedApplication].windows.firstObject;
        UIView *rootView = window.rootViewController.view;
        if (!rootView) {
            NSLog(@"[ESP-AI] Root view not ready; retrying overlay attach (%d)",g_overlayInitRetryCount+1);
            if (g_overlayInitRetryCount++<30) dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(0.5*NSEC_PER_SEC)),
                dispatch_get_main_queue(), ^{ setupGestureAndShowImGui(); });
            return;
        }
        g_overlayInitRetryCount=0;

        if (!hideViewSylphin3107) {
            CGRect screenBounds = [UIScreen mainScreen].bounds;
            hideViewSylphin3107 = [[HeeeNoScreenShotView alloc] initWithFrame:screenBounds];
            hideViewSylphin3107.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
            // Start with maskContent OFF (normal mode), touch passthrough
            hideViewSylphin3107.maskContent = NO;
            hideViewSylphin3107.passTouchToContent = NO;
            [rootView addSubview:hideViewSylphin3107];
        }

        if (_sharedImGuiDrawView.view.superview == nil) {
            [hideViewSylphin3107 addSubview:_sharedImGuiDrawView.view];
            _sharedImGuiDrawView.view.userInteractionEnabled = YES;
            _sharedImGuiDrawView.view.multipleTouchEnabled = YES;
        }

        EnableMultiTouchForGameAndImGui(_sharedImGuiDrawView.view);
        setupGestureRecognizer();

        // Reveal menu soon after attaching so first launch cannot look blank.
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            g_menuVisible = true;
        });
    });
}


@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id<MTLDevice>       device;
@property (nonatomic, strong) id<MTLCommandQueue>  commandQueue;
@property (nonatomic, assign) CFTimeInterval       lastFrameTime;
@end

@implementation ImGuiDrawView

+ (void)load {
    [super load];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        // Test/enterprise mode: bypass paid API + anti-crack checks, boot UI directly.
        ESP_InitPool();
        ESP_LoadSettings();
        setupGestureAndShowImGui();
    });
}

+ (void)showChange:(BOOL)open {
    g_menuVisible = open;
}

- (MTKView *)mtkView {
    return (MTKView *)self.view;
}

- (void)loadView {
    CGFloat w = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width;
    CGFloat h = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height;
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _device = MTLCreateSystemDefaultDevice();
        _commandQueue = [_device newCommandQueue];

        if (!_device) {
            NSLog(@"[ESP-AI] ERROR: Metal not available!");
            return self;
        }

        // ── ImGui init ──
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();

        ImGuiIO &io = ImGui::GetIO();
        io.IniFilename = NULL;
        io.LogFilename = NULL;
        io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;

        // ── Style ──
        ImGui::StyleColorsDark();
        ESP_ApplyStyle();

        // ── Fonts ──
        ImFont* font = io.Fonts->AddFontFromMemoryCompressedTTF((void*)zzz_compressed_data, zzz_compressed_size, 40, NULL, io.Fonts->GetGlyphRangesVietnamese());

        // Font Awesome icon font config
        static const ImWchar icons_ranges[] = { 0xf000, 0xf999, 0 };
        ImFontConfig icons_config;
        icons_config.MergeMode = true;
        icons_config.PixelSnapH = true;

        ImFont* fontAwesome = io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 25, &icons_config, icons_ranges);
        font->FontSize = 5;
        ImGui_ImplMetal_Init(_device);

        // ── Pass Metal device to ESP ──
        g_espMetalDevice = _device;

        self.lastFrameTime = CACurrentMediaTime();

        NSLog(@"[ESP-AI] ImGuiDrawView initialized");
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.mtkView.device = self.device;
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;

    self.mtkView.preferredFramesPerSecond = 60;

    // Use event-driven rendering to reduce wakeups when possible
    self.mtkView.enableSetNeedsDisplay = NO;  // We want continuous rendering for ESP
    self.mtkView.paused = NO;
}

- (void)Guest2 {
    // Placeholder — reset data if needed
}

- (void)updateIOWithTouchEvent:(UIEvent *)event {
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);

    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches) {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled) {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self updateIOWithTouchEvent:event];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self updateIOWithTouchEvent:event];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self updateIOWithTouchEvent:event];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self updateIOWithTouchEvent:event];
}

// ============================================================================
// MTKViewDelegate — render loop
// ============================================================================

- (void)mtkView:(MTKView *)view drawableSizeWillChange:(CGSize)size {
    // Nothing needed
}

- (void)drawInMTKView:(MTKView *)view {
    @autoreleasepool {
        ImGuiIO &io = ImGui::GetIO();
        io.DisplaySize.x = view.bounds.size.width;
        io.DisplaySize.y = view.bounds.size.height;

        CFTimeInterval currentTime = CACurrentMediaTime();
        float deltaTime = (float)(currentTime - self.lastFrameTime);
        if (deltaTime <= 0.0f || deltaTime > 0.1f) deltaTime = 1.0f / 60.0f;
        io.DeltaTime = deltaTime;
        self.lastFrameTime = currentTime;

        static CGFloat cachedScale = 0;
        if (cachedScale == 0) {
            cachedScale = view.window.screen.nativeScale ?: [UIScreen mainScreen].nativeScale;
        }
        io.DisplayFramebufferScale = ImVec2(cachedScale, cachedScale);

        // ── NoScreenShot toggle (just flip maskContent, no view moving) ──
        static bool wasNoScreenShot = false;
        if (g_noScreenShot != wasNoScreenShot) {
            wasNoScreenShot = g_noScreenShot;
            dispatch_async(dispatch_get_main_queue(), ^{
                if (hideViewSylphin3107) {
                    hideViewSylphin3107.maskContent = g_noScreenShot;
                    NSLog(@"[ESP-AI] NoScreenShot: %s", g_noScreenShot ? "ON" : "OFF");
                }
            });
        }
        // Touch control:
        // - When menu visible: hideView passes touch to MTKView (ImGui handles it)
        // - When menu hidden: hideView returns nil in hitTest, touch goes to game
        if (hideViewSylphin3107) {
            hideViewSylphin3107.passTouchToContent = g_menuVisible;
        }
        [self.view setUserInteractionEnabled:YES];

        // ── Render ──
        MTLRenderPassDescriptor *rpd = view.currentRenderPassDescriptor;
        if (rpd == nil) return;

        id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
        if (!commandBuffer) return;

        id<MTLRenderCommandEncoder> encoder = [commandBuffer renderCommandEncoderWithDescriptor:rpd];
        [encoder pushDebugGroup:@"ImGui ESP-AI"];

        ImGui_ImplMetal_NewFrame(rpd);
        if (g_uiStyleDirty) { ESP_ApplyStyle(); g_uiStyleDirty = false; }
        ImGui::NewFrame();
        ESP_ApplyLiveAccentStyle();

        // Scale font once
        static dispatch_once_t fontScaleOnce;
        dispatch_once(&fontScaleOnce, ^{
            ImFont *font = ImGui::GetFont();
            font->Scale = 15.f / font->FontSize;
        });

        // ── AutoPlay update ──
        @try {
            AutoPlay::Update();
        } @catch (NSException *e) {
            NSLog(@"[ESP-AI] AutoPlay exception: %@", e);
        }

        // ── AutoQueue update ──
        @try {
            AutoQueue::Update();
        } @catch (NSException *e) {
            NSLog(@"[ESP-AI] AutoQueue exception: %@", e);
        }

        // ── ESP overlay (always drawn) ──
        ImDrawList *bgDrawList = ImGui::GetBackgroundDrawList();
        @try {
            ESP_Update(bgDrawList);
        } @catch (NSException *e) {
            NSLog(@"[ESP-AI] ESP_Update exception: %@", e);
        }

        // ── iOS-inspired, responsive menu reveal ──
        static float reveal = 0.f;
        const float targetReveal = g_menuVisible ? 1.f : 0.f;
        if (ESP_ReduceMotion()) reveal = targetReveal;
        else {
            const float step=fminf(1.f,io.DeltaTime/0.18f);
            if (reveal<targetReveal) reveal=fminf(targetReveal,reveal+step);
            else if (reveal>targetReveal) reveal=fmaxf(targetReveal,reveal-step);
        }
        const float revealEase=reveal*reveal*(3.f-2.f*reveal);
        if (g_menuVisible || reveal > 0.012f) {
            const int dimAlpha=(int)(58.f*revealEase);
            if (dimAlpha>0) ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(0,0),io.DisplaySize,IM_COL32(0,0,0,dimAlpha));
            const CGFloat maxW = fmaxf(320.f, view.bounds.size.width - 16.f);
            const CGFloat maxH = fmaxf(260.f, view.bounds.size.height - 16.f);
            const CGFloat baseW = fminf(maxW, fmaxf(420.f, view.bounds.size.width * 0.82f));
            const CGFloat baseH = fminf(maxH, fmaxf(300.f, view.bounds.size.height * 0.82f));
            const CGFloat menuScale = ESP_ReduceMotion() ? 1.f : (0.965f + 0.035f * revealEase);
            const CGFloat menuW = baseW * menuScale;
            const CGFloat menuH = baseH * menuScale;
            const CGFloat x = (view.bounds.size.width - menuW) * 0.5f;
            const CGFloat y = (view.bounds.size.height - menuH) * 0.5f;
            g_uiResponsiveScale = fmaxf(0.78f, fminf(1.12f, fminf(baseW / 640.f, baseH / 380.f)));
            ImGui::SetNextWindowPos(ImVec2(x, y), ImGuiCond_Always);
            ImGui::SetNextWindowSize(ImVec2(menuW, menuH), ImGuiCond_Always);
            const ImGuiStyle &style = ImGui::GetStyle();
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, revealEase);
            ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(style.WindowPadding.x * g_uiResponsiveScale, style.WindowPadding.y * g_uiResponsiveScale));
            ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(style.FramePadding.x * g_uiResponsiveScale, style.FramePadding.y * g_uiResponsiveScale));
            ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(style.ItemSpacing.x * g_uiResponsiveScale, style.ItemSpacing.y * g_uiResponsiveScale));
            ImGui::Begin(ICON_FA_EYE " 8 ball Pol System", &g_menuVisible,
                        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings);
            ESP_DrawMenu();
            ImGui::End();
            ImGui::PopStyleVar(4);
        }
        if (!g_menuVisible && reveal < 0.05f) DrawFloatingMenuLauncher(io.DisplaySize);
        ESP_DrawToast();

        // ── Finalize ──
        ImGui::Render();
        ImGui_ImplMetal_RenderDrawData(ImGui::GetDrawData(), commandBuffer, encoder);

        [encoder popDebugGroup];
        [encoder endEncoding];

        id<CAMetalDrawable> drawable = view.currentDrawable;
        if (drawable) {
            [commandBuffer presentDrawable:drawable];
        }
        [commandBuffer commit];
    }
}

@end
